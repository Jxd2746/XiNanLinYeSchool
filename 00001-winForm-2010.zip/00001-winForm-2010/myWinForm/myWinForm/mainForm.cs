﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using myWinForm.common;
using myWinForm.core.classManage;

namespace myWinForm
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }
        public mainForm(Action act)
        {
            InitializeComponent();
            act();
        }

        private void 班级管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            classManageForm editForm = new classManageForm();
            editForm.ShowDialog();
        }
        

        private void 退出系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
            DialogResult dr = MessageBox.Show("确定要退出吗?", "退出系统", messButton);
            if (dr == DialogResult.OK)//如果点击“确定”按钮
            {
                System.Environment.Exit(0);
            }
                
        }
    }
}
