﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Configuration;
using System.Data.SqlClient;
using System.Threading;
using myWinForm.common;

namespace myWinForm
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        //SqlConnection myConnection = new SqlConnection(
        //    ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString);

        private void button1_Click(object sender, EventArgs e)
        {
            var userStr = textBox1.Text;
            var passwdStr = textBox2.Text;
            if (dbClass.isExistUser(userStr, passwdStr))
            {
                MessageBox.Show("登录成功");
                Thread th = new Thread(new ThreadStart(delegate
                {
                    Application.Run(new mainForm(FormClose));
                }));

                th.Start();
            }
            else {
                MessageBox.Show("用户名或密码错误！");
            }
        }
        private void FormClose()
        {
            this.BeginInvoke(new MethodInvoker(delegate { this.Close(); }));
        }
    }
}
