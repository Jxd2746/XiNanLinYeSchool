﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
//using System.Configuration;
using System.Data.SqlClient;
using myWinForm.common;

namespace myWinForm.common
{
    class dbClass
    {
        //SqlConnection myConnection = new SqlConnection(
        //    ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString);

        #region 数据库连接及增删改查
        public static SqlConnection getConnection()
        {
            SqlConnection myConnection = new SqlConnection("Data Source=.;Initial Catalog=stuScoreDB;User ID=sa;Password=123456");
            return myConnection;
        }


        public static void Open(SqlConnection myConnection)
        {
            myConnection.Open();
        }
        public static void Close(SqlConnection myConnection)
        {
            myConnection.Close();
        }

        /// <summary>
        /// 执行sql语句，完成：添加，修改，删除
        /// </summary>
        /// <param name="sql">SQL语句</param>
        public static void executeSql(string sql)
        {
            SqlConnection myConnection = getConnection();
            Open(myConnection);
            SqlCommand myCommand = new SqlCommand(sql, myConnection);
            myCommand.ExecuteNonQuery();
            Close(myConnection);
        }
        #endregion


        /// <summary>
        /// 判断账号的合法性
        /// </summary>
        /// <param name="userStr">用户输入的用户名（账号）</param>
        /// <param name="passwdStr">用户输入的密码</param>
        /// <returns></returns>
        public static bool isExistUser(string userStr,string passwdStr) {
            bool ishave = false;
            string passwdStrMD5 = pub.MD5Encrypt32(passwdStr);
            SqlConnection myConnection = getConnection();
            Open(myConnection);
            var sql = "select * from userTable where userName='" + userStr + "' and passwd='" + passwdStrMD5 + "'";
            SqlCommand myCommand = new SqlCommand(sql, myConnection);
            SqlDataAdapter Adapter = new SqlDataAdapter();
            Adapter.SelectCommand = myCommand;
            DataSet myDs = new DataSet();
            Adapter.Fill(myDs);
            DataTable myTable = myDs.Tables[0];
            var n = myTable.Rows.Count;
            if (n > 0)
            {
                ishave = true;
            }
            else {
                ishave = false;
            }
            //foreach (DataRow myRow in myTable.Rows)
            //{
            //    var user = myRow["userName"];
            //    var passwd = myRow["passwd"];

            //}
            //SqlCommand cmd = new SqlCommand();
            //cmd.Connection = myConnection;
            //cmd.CommandText = "select * from userTable";
            Close(myConnection);
            return ishave;
        }

        /// <summary>
        /// 判断数据库中是否有数据
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static bool ishave(string sql)
        {
            bool ishave = false;
            SqlConnection myConnection = getConnection();
            Open(myConnection);
            SqlCommand myCommand = new SqlCommand(sql, myConnection);
            SqlDataAdapter Adapter = new SqlDataAdapter();
            Adapter.SelectCommand = myCommand;
            DataSet myDs = new DataSet();
            Adapter.Fill(myDs);
            DataTable myTable = myDs.Tables[0];
            var n = myTable.Rows.Count;
            if (n > 0)
            {
                ishave = true;
            }
            else
            {
                ishave = false;
            }
            Close(myConnection);
            return ishave;
        }

        //获取DataSet
        public static DataSet getDateSet(string sql)
        {
            SqlConnection myConnection = getConnection();
            Open(myConnection);
            SqlCommand myCommand = new SqlCommand(sql, myConnection);
            SqlDataAdapter Adapter = new SqlDataAdapter();
            Adapter.SelectCommand = myCommand;
            DataSet myDs = new DataSet();
            Adapter.Fill(myDs);
            Close(myConnection);
            return myDs;
        }
        //获取DataTable
        public static DataTable getDataTable(string sql) {
            SqlConnection myConnection = getConnection();
            Open(myConnection);
            SqlCommand myCommand = new SqlCommand(sql, myConnection);
            SqlDataAdapter Adapter = new SqlDataAdapter();
            Adapter.SelectCommand = myCommand;
            DataSet myDs = new DataSet();
            Adapter.Fill(myDs);
            DataTable myTable = myDs.Tables[0];
            Close(myConnection);
            return myTable;
        }
    }
}
