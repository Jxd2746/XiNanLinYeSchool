﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using myWinForm.common;

namespace myWinForm.core.classManage
{
    public partial class editClassForm : Form
    {
        int thisclassID = 0;
        public DataGridView _dgv;
        public editClassForm()
        {
            InitializeComponent();
        }
        public editClassForm(int classID,string className, DataGridView dgv)
        {
            InitializeComponent();
            textBox1.Text = className;
            thisclassID = classID;
            _dgv = dgv;
        }

        private void saveEditClassButton_Click(object sender, EventArgs e)
        {
            var sql = "update classTable set className='" + textBox1.Text.Trim() + "' where classID=" + thisclassID;
            dbClass.executeSql(sql);
            MessageBox.Show("修改成功");
            this.Close();
            //classManageForm cmf = new classManageForm();
            //cmf.classDataGridViewRefresh();
            //cmf.Refresh();
            //cmf.dataGridView1.Refresh();
            string sql2 = "select * from classTable";
            _dgv.DataSource = dbClass.getDataTable(sql2);
        }
    }
}
