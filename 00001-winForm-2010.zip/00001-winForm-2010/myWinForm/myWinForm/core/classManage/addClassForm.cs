﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using myWinForm.common;

namespace myWinForm.core.classManage
{
    public partial class addClassForm : Form
    {
        DataGridView _dgv;
        public addClassForm()
        {
            InitializeComponent();
        }
        public addClassForm(DataGridView dgv)
        {
            InitializeComponent();
            _dgv = dgv;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var newClassName = textBox1.Text;
            if (string.IsNullOrEmpty(newClassName)) {
                MessageBox.Show("班级名称不允许为空");
                return;
            }
            var sql = "insert into classTable(className) values('"+newClassName+"')";
            dbClass.executeSql(sql);
            MessageBox.Show("添加班级成功");
            this.Close();


            var sql2 = "select * from classTable";
            _dgv.DataSource = dbClass.getDataTable(sql2);
        }
    }
}
