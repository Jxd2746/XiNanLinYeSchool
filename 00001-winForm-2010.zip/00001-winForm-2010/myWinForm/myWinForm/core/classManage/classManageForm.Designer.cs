﻿namespace myWinForm.core.classManage
{
    partial class classManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.addClassBtn = new System.Windows.Forms.Button();
            this.editClassBtn = new System.Windows.Forms.Button();
            this.delClassBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.selectClassBtn = new System.Windows.Forms.Button();
            this.allClassBtn = new System.Windows.Forms.Button();
            this.classTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.classTableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // addClassBtn
            // 
            this.addClassBtn.Location = new System.Drawing.Point(39, 31);
            this.addClassBtn.Name = "addClassBtn";
            this.addClassBtn.Size = new System.Drawing.Size(185, 52);
            this.addClassBtn.TabIndex = 0;
            this.addClassBtn.Text = "添加";
            this.addClassBtn.UseVisualStyleBackColor = true;
            this.addClassBtn.Click += new System.EventHandler(this.addClassBtn_Click);
            // 
            // editClassBtn
            // 
            this.editClassBtn.Location = new System.Drawing.Point(260, 29);
            this.editClassBtn.Name = "editClassBtn";
            this.editClassBtn.Size = new System.Drawing.Size(209, 54);
            this.editClassBtn.TabIndex = 1;
            this.editClassBtn.Text = "修改";
            this.editClassBtn.UseVisualStyleBackColor = true;
            this.editClassBtn.Click += new System.EventHandler(this.editClassBtn_Click);
            // 
            // delClassBtn
            // 
            this.delClassBtn.Location = new System.Drawing.Point(534, 31);
            this.delClassBtn.Name = "delClassBtn";
            this.delClassBtn.Size = new System.Drawing.Size(204, 55);
            this.delClassBtn.TabIndex = 2;
            this.delClassBtn.Text = "删除";
            this.delClassBtn.UseVisualStyleBackColor = true;
            this.delClassBtn.Click += new System.EventHandler(this.delClassBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(29, 111);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 37;
            this.dataGridView1.Size = new System.Drawing.Size(1291, 616);
            this.dataGridView1.TabIndex = 0;
            // 
            // selectClassBtn
            // 
            this.selectClassBtn.Location = new System.Drawing.Point(804, 31);
            this.selectClassBtn.Name = "selectClassBtn";
            this.selectClassBtn.Size = new System.Drawing.Size(220, 52);
            this.selectClassBtn.TabIndex = 3;
            this.selectClassBtn.Text = "查询班级";
            this.selectClassBtn.UseVisualStyleBackColor = true;
            this.selectClassBtn.Click += new System.EventHandler(this.selectClassBtn_Click);
            // 
            // allClassBtn
            // 
            this.allClassBtn.Location = new System.Drawing.Point(1067, 26);
            this.allClassBtn.Name = "allClassBtn";
            this.allClassBtn.Size = new System.Drawing.Size(216, 57);
            this.allClassBtn.TabIndex = 4;
            this.allClassBtn.Text = "所有班级";
            this.allClassBtn.UseVisualStyleBackColor = true;
            this.allClassBtn.Click += new System.EventHandler(this.allClassBtn_Click);
            // 
            // classManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1486, 901);
            this.Controls.Add(this.allClassBtn);
            this.Controls.Add(this.selectClassBtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.delClassBtn);
            this.Controls.Add(this.editClassBtn);
            this.Controls.Add(this.addClassBtn);
            this.Name = "classManageForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "班级管理";
            this.Load += new System.EventHandler(this.classManageForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.classTableBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button addClassBtn;
        private System.Windows.Forms.Button editClassBtn;
        private System.Windows.Forms.Button delClassBtn;
        private System.Windows.Forms.BindingSource classTableBindingSource;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button selectClassBtn;
        private System.Windows.Forms.Button allClassBtn;
    }
}