﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using myWinForm.common;


namespace myWinForm.core.classManage
{
    public partial class classManageForm : Form
    {
        public classManageForm()
        {
            InitializeComponent();
        }


        private void editClassBtn_Click(object sender, EventArgs e)
        {
            var dgvRow = dataGridView1.SelectedRows;
            if (dgvRow.Count == 0) {
                MessageBox.Show("必须选中一行才行修改！");
                return;
            }
            
            DataGridViewRow selRow = dataGridView1.SelectedRows[0];
            var cell0 = selRow.Cells[0].Value.ToString();
            var cell1 = selRow.Cells[1].Value.ToString();
            var classID = Convert.ToInt32(cell0);
            var className = cell1;
            editClassForm editForm = new editClassForm(classID, className,dataGridView1);
            editForm.ShowDialog();
        }

        //刷新班级DataGridView
        public void classDataGridViewRefresh()
        {
            clearDataGridView(dataGridView1);
            dataGridView1.DataSource = null;
            string sql = "select * from classTable";
            dataGridView1.DataSource = dbClass.getDataTable(sql);

            dataGridView1.Refresh();
            //dataGridView1.RefreshEdit();
            //MessageBox.Show("刷新班级DataGridView");
        }

        public void clearDataGridView(DataGridView dgv) {
            if (dgv.DataSource != null)
            {
                DataTable dt = (DataTable)dgv.DataSource;
                dt.Rows.Clear();
                dgv.DataSource = dt;
            }
            else
            {
                dgv.Rows.Clear();
            }
        }

        private void classManageForm_Load(object sender, EventArgs e)
        {
            string sql = "select * from classTable";
            dataGridView1.DataSource = dbClass.getDataTable(sql);
        }

        private void addClassBtn_Click(object sender, EventArgs e)
        {
            addClassForm acf = new addClassForm(dataGridView1);
            acf.ShowDialog();
        }

        private void delClassBtn_Click(object sender, EventArgs e)
        {
            var datagridviewrow = dataGridView1.SelectedRows;
            if (datagridviewrow.Count == 0) {
                MessageBox.Show("请选择一行删除");
                return;
            }

            var selrow = dataGridView1.SelectedRows[0];
            var classID =Convert.ToInt32(selrow.Cells[0].Value.ToString());
            var delsql = "delete from classTable where classID="+classID;
            dbClass.executeSql(delsql);
            MessageBox.Show("删除成功");

            var selsql = "select * from classTable";
            dataGridView1.DataSource = dbClass.getDataTable(selsql);

        }

        private void selectClassBtn_Click(object sender, EventArgs e)
        {
            selectClassForm scf = new selectClassForm(dataGridView1);
            scf.ShowDialog();
        }

        private void allClassBtn_Click(object sender, EventArgs e)
        {
            var selsql = "select * from classTable";
            dataGridView1.DataSource = dbClass.getDataTable(selsql);
        }
    }
}
